# This script can be run with an installed verovio package or from a CMake
# build directory such as ./bindings/python.
import argparse
import importlib.resources as resources
import json
import os
import sys
import xml.etree.ElementTree as ET

from cairosvg import svg2png

# Add path for toolkit built in-place
sys.path.append('./verovio')
import verovio

ns = {'mei': 'http://www.music-encoding.org/ns/mei'}

# Optional list for processing only listed test files
# Files must be listed in a file passed with --shortlist, one by line
# Ex. 'accid/accid-001.mei'
shortlist = []

testOptions = {
    'adjustPageHeight': True,
    'breaks': 'auto',
    'pageHeight': 2970,
    'pageWidth': 2100,
    'header': 'none',
    'footer': 'none',
    'scale': 40,
    'spacingStaff': 4
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('test_suite_dir')
    parser.add_argument('output_dir')
    parser.add_argument('--shortlist', nargs='?', default='')
    args = parser.parse_args()

    # version of the toolkit
    tk = verovio.toolkit(False)
    print(f"Verovio {tk.getVersion()}")

    resource_path = None
    source_tree_data = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data"
    )
    package_data = resources.files(verovio) / "data"

    # 1. Allow setting the resource path directly
    if p := os.environ.get("VEROVIO_RESOURCE_PATH"):
        resource_path = p
    # 2. Try to auto-discover it from the package
    elif package_data.is_dir():
        resource_path = str(package_data)
    # 3. Try to discover it from the external source tree.
    elif os.path.isdir(source_tree_data):
        resource_path = source_tree_data

    # If no resource path is found, exit with an error.
    if resource_path is None:
        print("Could not discover resources path. Exiting.")
        sys.exit(-1)

    print(f"Setting resource path to {resource_path}")
    tk.setResourcePath(resource_path)

    # look if we have a shortlist file and read it
    if len(args.shortlist) > 0:
        print(args.shortlist)
        with open(args.shortlist) as f:
            for line in f:
                shortlist.append(line.strip('\n'))
                print('File {} added to the shortlist'.format(line))

    path1 = args.test_suite_dir.replace(r"\ ", " ")
    path2 = args.output_dir.replace(r"\ ", " ")
    dir1 = sorted(os.listdir(path1))
    for item1 in dir1:
        if not (os.path.isdir(os.path.join(path1, item1))):
            continue

        # create the output directory if necessary
        if not (os.path.isdir(os.path.join(path2, item1))):
            os.mkdir(os.path.join(path2, item1))

        dir2 = sorted(os.listdir(os.path.join(path1, item1)))
        for item2 in dir2:
            # skip directories
            if not (os.path.isfile(os.path.join(path1, item1, item2))):
                continue
            # skip hidden files
            if item2.startswith('.'):
                continue

            if shortlist and not (os.path.join(item1, item2) in shortlist):
                continue

            # reset the options
            options = testOptions.copy()

            # filenames (input MEI/XML and output SVG)
            inputFile = os.path.join(path1, item1, item2)
            options.update({"xmlIdChecksum": True})
            print(f'Rendering {item2}')
            name, ext = os.path.splitext(item2)
            svgFile = os.path.join(path2, item1, name + '.svg')
            pngFile = os.path.join(path2, item1, name + '.png')
            timeMapFile = os.path.join(path2, item1, name + '.json')
            midiFile = os.path.join(path2, item1, name + '.mid')

            # parse the MEI file
            if ext == '.mei':
                tree = ET.parse(inputFile)
                root = tree.getroot()
                # try to get the extMeta tag and load the options if existing
                meta = root.findtext(
                    './/mei:meiHead/mei:extMeta', namespaces=ns)
                if meta is not None and meta != '':
                    # print(meta)
                    metaOptions = json.loads(meta)
                    options |= metaOptions

            tk.setOptions(options)
            tk.loadFile(inputFile)
            # render to SVG
            svgString = tk.renderToSVG(1)
            ET.ElementTree(ET.fromstring(svgString)).write(svgFile)
            svg2png(bytestring=svgString, scale=2, write_to=pngFile)
            # create time map
            tk.renderToTimemapFile(timeMapFile)
            # create MIDI file
            tk.renderToMIDIFile(midiFile)
            tk.resetOptions()
            options.clear()
